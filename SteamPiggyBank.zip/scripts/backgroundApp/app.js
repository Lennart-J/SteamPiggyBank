var app = angular.module('backgroundApp', ['backgroundApp.controllers', 'backgroundApp.services']);

app.run(function() {
  console.log('Hello world');
});